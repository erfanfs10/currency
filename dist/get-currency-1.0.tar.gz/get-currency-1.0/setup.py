from setuptools import setup

setup(
    name='get-currency',
    version='1.0',
    packages=['currency'],
    install_requires=['requests'],
    zip_safe=False
)
